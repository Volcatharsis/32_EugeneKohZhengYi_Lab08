﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Script : MonoBehaviour
{
    public GameObject ScoreText;

    int SpaceBarCount = 0;

    // Start is called before the first frame update
    void Start()
    {
        ScoreText.GetComponent<Text>().text = "Spacebar: " + SpaceBarCount;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            SpaceBarCount += 1;
            print("SpaceBarCount = " + SpaceBarCount);
        }
    }
}
